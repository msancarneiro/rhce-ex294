SELECT count(*)
FROM pg_prepared_xacts
