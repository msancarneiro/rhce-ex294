#!/usr/bin/env bash
echo "traces in tmp" | tee -a /tmp/test_traces.tmp
#echo "traces in tmp" >> /tmp/test_traces.tmp
