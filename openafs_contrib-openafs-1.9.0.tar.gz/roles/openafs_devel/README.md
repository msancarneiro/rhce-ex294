# Ansible Role: OpenAFS development

Install development packages and provide modules to build an OpenAFS binary
distribution from source code.

Documentation: [https://openafs-ansible-collection.readthedocs.io][1]

## License

BSD

## Author Information

Copyright (c) 2018-2021 Sine Nomine Associates

[1]: https://openafs-ansible-collection.readthedocs.io/en/latest/
