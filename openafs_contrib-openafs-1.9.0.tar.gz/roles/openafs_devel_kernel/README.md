# Ansible Role: OpenAFS kernel development

Install development packages and to build an OpenAFS kernel
module.

Documentation: [https://openafs-ansible-collection.readthedocs.io][1]

## License

BSD

## Author Information

Copyright (c) 2018-2021 Sine Nomine Associates

[1]: https://openafs-ansible-collection.readthedocs.io/en/latest/
