# Ansible Collection - mafalb.squid

|||
|---|---|
|master|![master branch](https://github.com/mafalb/ansible-collection-squid/workflows/CI/badge.svg?branch=master)|
|dev|![dev branch](https://github.com/mafalb/ansible-collection-squid/workflows/CI/badge.svg?branch=dev)|

An ansible collection for squid.

## Roles

### [mafalb.squid.server](roles/server/README.md)

## License

Copyright (c) 2020,2021 Markus Falb <markus.falb@mafalb.at>

GPL-3.0-or-later